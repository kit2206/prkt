package com.example.ppdiplom

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ActivityMenu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu)
        val button_INF = findViewById<Button>(R.id.button_INF)
        button_INF.setOnClickListener {
            val intent = Intent(this, Activity_info::class.java)
            startActivity(intent)
        }
        val button_stat = findViewById<Button>(R.id.button_stat)
        button_stat.setOnClickListener {
            val intent = Intent(this, Activity_statys::class.java)
            startActivity(intent)

        }
        val buttonActivity_Gallary = findViewById<Button>(R.id.button_gallary)
        buttonActivity_Gallary.setOnClickListener {
            val intent = Intent(this, Activity_Gallary::class.java)
            startActivity(intent)

        }
        val buttonpokypka = findViewById<Button>(R.id.button_pokupka)
        buttonpokypka.setOnClickListener {
            val intent = Intent(this, Activity_Pokypka::class.java)
            startActivity(intent)

        }
    }
}