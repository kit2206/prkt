package com.example.ppdiplom

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Activity_Gallary : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_gallary)
        val button_back3 = findViewById<Button>(R.id.button_back3)
        button_back3.setOnClickListener {
            val intent = Intent(this, ActivityMenu::class.java)
            startActivity(intent)

        }

    }
}