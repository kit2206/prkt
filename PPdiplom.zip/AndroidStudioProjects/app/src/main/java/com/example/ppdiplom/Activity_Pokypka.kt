package com.example.ppdiplom

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Activity_Pokypka : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pokypka)
        val imageButton: ImageButton = findViewById(R.id.imageButton4) // Замените R.id.imageButton на ваш id

        imageButton.setOnClickListener {
            val intent = Intent(this, Activity_Albom::class.java) // Замените SecondActivity::class.java на имя вашего нового Activity
            startActivity(intent)
        }
        val button_back4 = findViewById<Button>(R.id.button_back4)
        button_back4.setOnClickListener {
            val intent = Intent(this, ActivityMenu::class.java)
            startActivity(intent)

        }
    }
}